function briefInfo1(x) {
    x.style.scale = "125%";
    text1.style.display = 'block';
    figcaption1.style.display = 'none';
}
function backToNormal1(x) {
    x.style.scale = "100%";
    text1.style.display = 'none';
    figcaption1.style.display = 'block';
}
function briefInfo2(x) {
    x.style.scale = "125%";
    text2.style.display = 'block';
    figcaption2.style.display = 'none';
}
function backToNormal2(x) {
    x.style.scale = "100%";
    text2.style.display = 'none';
    figcaption2.style.display = 'block';
}
function briefInfo3(x) {
    x.style.scale = "125%";
    text3.style.display = 'block';
    figcaption3.style.display = 'none';
}
function backToNormal3(x) {
    x.style.scale = "100%";
    text3.style.display = 'none';
    figcaption3.style.display = 'block';
}
function briefInfo4(x) {
    x.style.scale = "125%";
    text4.style.display = 'block';
    figcaption4.style.display = 'none';
}
function backToNormal4(x) {
    x.style.scale = "100%";
    text4.style.display = 'none';
    figcaption4.style.display = 'block';
}
function briefInfo5(x) {
    x.style.scale = "125%";
    text5.style.display = 'block';
    figcaption5.style.display = 'none';
}
function backToNormal5(x) {
    x.style.scale = "100%";
    text5.style.display = 'none';
    figcaption5.style.display = 'block';
}
function briefInfo6(x) {
    x.style.scale = "125%";
    text6.style.display = 'block';
    figcaption6.style.display = 'none';
}
function backToNormal6(x) {
    x.style.scale = "100%";
    text6.style.display = 'none';
    figcaption6.style.display = 'block';
}
function briefInfo7(x) {
    x.style.scale = "150%";
    text7.style.display = 'block';
    figcaption7.style.display = 'none';
}
function backToNormal7(x) {
    x.style.scale = "100%";
    text7.style.display = 'none';
    figcaption7.style.display = 'block';
}
function briefInfo8(x) {
    x.style.scale = "125%";
    text8.style.display = 'block';
    figcaption8.style.display = 'none';
}
function backToNormal8(x) {
    x.style.scale = "100%";
    text8.style.display = 'none';
    figcaption8.style.display = 'block';
}
